#include "php.h"
#include "xcache.h"

void xc_optimizer_op_array_handler(zend_op_array *op_array);
