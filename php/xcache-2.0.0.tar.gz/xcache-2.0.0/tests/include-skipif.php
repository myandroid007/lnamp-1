<?php
if (version_compare(PHP_VERSION, '5.3.0', '<')) {
	die('skip __DIR__ not supported in this php version');
}
?>
