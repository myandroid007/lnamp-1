<?php

echo __DIR__, PHP_EOL;
echo __FILE__, PHP_EOL;

